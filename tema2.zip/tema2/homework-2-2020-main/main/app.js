function addTokens(input, tokens) {

    validations(input, tokens);

    if (input.includes("..."))
        for (let i = 0; i < tokens.length; i++) {
            input = input.replace("...", "${" + `${tokens[i].tokenName}` + "}")
        }

    return input;

}

const app = {
    addTokens: addTokens
}

function validations(input, tokens) {

    if (typeof input !== 'string')
        throw new Error(`Invalid input`);

    if (input.length < 6)
        throw new Error('Input should have at least 6 characters');

    for (let i = 0; i < tokens.length; i++) {
        if (typeof tokens[i].tokenName !== 'string')
            throw new Error(`Invalid array format`);
    }
}


module.exports = app;